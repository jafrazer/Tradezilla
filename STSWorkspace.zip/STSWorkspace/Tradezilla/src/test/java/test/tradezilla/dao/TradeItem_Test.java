package test.tradezilla.dao;

public class TradeItem_Test {
//	@Tested TradeItem tradeItem;
//
//	
//	@Test
//	public void createTradeItem_test() {
//		TradeItemInfo createdItem = new TradeItem().createTradeItem(TestConsts.username, TestConsts.itemName, TestConsts.itemDescription);
//		
//		readByUsernameAndItemName_test(createdItem.getItemId(), createdItem.getUsername());
//	}
//	
//	@Test
//	public void readTradeItemListForUser_test() {
//		ArrayList<TradeItemInfo> testData = new ArrayList<TradeItemInfo>();
//		testData.add(new TradeItemInfo("0", TestConsts.itemName, TestConsts.username, TestConsts.itemDescription));
//		
//		ArrayList<TradeItemInfo> expectedResult = new TradeItem().readTradeItemListForUser(TestConsts.username);
//		
//		assertEquals(expectedResult, testData);
//	}
//	
//	@Test
//	public void readTradeItem_test() {
//		TradeItemInfo testData = new TradeItemInfo("0", TestConsts.itemName, TestConsts.username, TestConsts.itemDescription);
//		TradeItemInfo itemToRead = new TradeItemInfo("0", TestConsts.blank, TestConsts.username, TestConsts.blank);
//		
//		TradeItemInfo expectedResult = new TradeItem().readTradeItem(itemToRead);
//		
//		assertEquals(expectedResult, testData);
//	}
//	
//	@Test
//	public void readByUsernameAndItemName_test(String id, String username) {
//		TradeItemInfo testData = new TradeItemInfo("0", TestConsts.itemName, TestConsts.username, TestConsts.itemDescription);
//		TradeItemInfo tradeItemInfo = new TradeItemInfo(id, username, TestConsts.blank, TestConsts.blank);
//		
//		TradeItemInfo expectedResult = new TradeItem().readTradeItem(tradeItemInfo);
//		
//		assertEquals(expectedResult, testData);
//	}
	
}
