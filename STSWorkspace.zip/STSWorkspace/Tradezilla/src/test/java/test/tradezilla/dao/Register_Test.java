package test.tradezilla.dao;

import org.junit.Test;

//import mockit.Tested;

public class Register_Test {
//	@Tested User user;

	@Test
	public void register_test() {
		// TODO
	}
	
	@Test
	public void checkForDuplicates_test() {
		// TODO
	}
	
	@Test
	public void addUserRole_test() {
		// TODO
	}
}
