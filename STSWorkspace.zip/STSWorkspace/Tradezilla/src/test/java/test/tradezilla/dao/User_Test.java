package test.tradezilla.dao;

public class User_Test {
//	@Tested User user_class;
//
//	@Autowired
//	User user;
//	@Autowired
//	JdbcTemplate jdbcTemplate;
//	@Autowired
//	DataSource dataSource;
//	
//	public void setDataSource(DataSource dataSource) {
//		this.dataSource = dataSource;
//	}
//	
//	@Test
//	public void readUserAccountInfo_test() {
//		jdbcTemplate = new JdbcTemplate(dataSource);
//		
//		UserAccountInfo testData = new UserAccountInfo(TestConsts.username, new EncryptPassword().encryptPassword(TestConsts.password), true);
//		
//		// TODO Test run
//		
//		UserAccountInfo expectedResult = new User().readUserAccountInfo(TestConsts.username);
//
////		System.out.println(testData.toString());
////		System.out.println(expectedResult.toString());
//		assertEquals(expectedResult, testData);
//	}
}
