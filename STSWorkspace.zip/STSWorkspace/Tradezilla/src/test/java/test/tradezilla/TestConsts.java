package test.tradezilla;

public class TestConsts {

	public static String username = "jaf";
	public static String password = "shels2004";
	public static String itemName = "test item 001";
	public static String itemDescription = "description";
	public static String blank = "";
}
