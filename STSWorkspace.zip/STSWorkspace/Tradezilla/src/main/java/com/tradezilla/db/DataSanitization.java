package com.tradezilla.db;

public class DataSanitization {
	
	/**
	 * Ensure that the provided data cannot be executed 
	 * @param dataToClean
	 * @return
	 */
	public String sanitizeString(String dataToClean) {
		
		// TODO Sanitize the data here: remove angle brackets, remove apostrophes
		
		return dataToClean;
	}
}
